from flask import Flask, request, jsonify, render_template, redirect, flash, send_file, Response
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib as mpl
import plotly.express as px
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator
from sklearn.model_selection import train_test_split
from sklearn.linear_model import PassiveAggressiveRegressor
import warnings
warnings.filterwarnings("ignore") 

mpl.rcParams["figure.figsize"] = [7, 7]
mpl.rcParams["figure.autolayout"] = True

app = Flask(__name__)

path = "Instagram_data.csv"
data = pd.read_csv(path, encoding = 'latin1')
data = data.dropna()
#train a machine learning model to predict the reach of an Instagram post. Let’s split the data into training and test sets before training the model:
x = np.array(data[['Likes', 'Saves', 'Comments', 'Shares', 
                   'Profile Visits', 'Follows']])
y = np.array(data["Impressions"])
xtrain, xtest, ytrain, ytest = train_test_split(x, y, 
                                                test_size=0.2, 
                                                random_state=42)
model = PassiveAggressiveRegressor()
model.fit(xtrain, ytrain)

def makeplot():
      i=0
      plt.figure(figsize=(10, 8))
      plt.style.use('fivethirtyeight')
      plt.title("Distribution of Impressions From Home")
      sns.distplot(data['From Home'])
      i=i+1
      plt.savefig(f'static/images/try{i}.png')

      plt.figure(figsize=(10, 8))
      plt.title("Distribution of Impressions From Hashtags")
      sns.distplot(data['From Hashtags'])
      i=i+1
      plt.savefig(f'static/images/try{i}.png')

      plt.figure(figsize=(10, 8))
      plt.title("Distribution of Impressions From Explore")
      sns.distplot(data['From Explore'])
      i=i+1
      plt.savefig(f'static/images/try{i}.png')

      home = data["From Home"].sum()
      hashtags = data["From Hashtags"].sum()
      explore = data["From Explore"].sum()
      other = data["From Other"].sum()

      labels = ['From Home','From Hashtags','From Explore','Other']
      values = [home, hashtags, explore, other]

      fig = px.pie(data, values=values, names=labels, 
                   title='Impressions on Instagram Posts From Various Sources', hole=0.5)
      i=i+1
      fig.write_image(f'static/images/try{i}.png')

      text = " ".join(i for i in data.Caption)
      stopwords = set(STOPWORDS)
      wordcloud = WordCloud(stopwords=stopwords, background_color="white").generate(text)
      plt.style.use('classic')
      plt.figure(figsize=(12,10))
      plt.imshow(wordcloud, interpolation='bilinear')
      plt.axis("off")
      i=i+1
      plt.savefig(f'static/images/try{i}.png')

      text = " ".join(i for i in data.Hashtags)
      stopwords = set(STOPWORDS)
      wordcloud = WordCloud(stopwords=stopwords, background_color="white").generate(text)
      plt.figure( figsize=(12,10))
      plt.imshow(wordcloud, interpolation='bilinear')
      plt.axis("off")
      i=i+1
      plt.savefig(f'static/images/try{i}.png')

      fig = px.scatter(data_frame = data, x="Impressions",
                    y="Likes", size="Likes", trendline="ols", 
                    title = "Relationship Between Likes and Impressions")
      i=i+1
      fig.write_image(f'static/images/try{i}.png')

      fig = px.scatter(data_frame = data, x="Impressions",
                    y="Comments", size="Comments", trendline="ols", 
                    title = "Relationship Between Comments and Total Impressions")
      i=i+1
      fig.write_image(f'static/images/try{i}.png')

      fig = px.scatter(data_frame = data, x="Impressions",
                    y="Shares", size="Shares", trendline="ols", 
                    title = "Relationship Between Shares and Total Impressions")
      i=i+1
      fig.write_image(f'static/images/try{i}.png')

      fig = px.scatter(data_frame = data, x="Impressions",
                    y="Saves", size="Saves", trendline="ols", 
                    title = "Relationship Between Post Saves and Total Impressions")
      i=i+1
      fig.write_image(f'static/images/try{i}.png')
      # Select only numeric columns
      numeric_data = data.select_dtypes(include=['int64'])

      # Calculate correlation
      correlation = numeric_data.corr()
      conversion_rate = (data["Follows"].sum() / data["Profile Visits"].sum()) * 100

      fig = px.scatter(data_frame = data, x="Profile Visits",
                    y="Follows", size="Follows", trendline="ols", 
                    title = "Relationship Between Profile Visits and Followers Gained")
      i=i+1
      fig.write_image(f'static/images/try{i}.png')






@app.route('/')

@app.route('/index')
def index():
      return render_template('index.html')

@app.route('/prediction')
def prediction():
      return render_template('prediction.html')

@app.route('/login')
def login():
      return render_template('login.html')

@app.route('/analysis')
def analysis():
      return render_template('analysis.html')


@app.route('/predict',methods=['POST'])
def predict():
      feature = [int(x) for x in request.form.values()]
      out = model.predict(np.array([feature]))
      #first_name = request.form.get("sku")
      return render_template('prediction.html', x = round(out[0]))



if __name__ == '__main__':

      makeplot()
      



      app.run(debug=True)
